document.addEventListener("keydown" , e =>{
   console.log(e);

});


//console.log;("hiii")